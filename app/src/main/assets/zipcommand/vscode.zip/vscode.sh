#!/data/data/com.termux/files/usr/bin/sh
echo "欢迎安装VSCODE(codeserver)"
echo "作者:xingyujie"
echo "此安装程序为ZeroTermux,Utermux准备"
echo "vscode可以让您快速编写代码,web界面，在线编码"
echo "使用xingyujie开发的vscode脚本不需要安装容器，因此非常快速方便"
echo "十秒钟后开始安装，请阅读"
sleep 10
echo "[*]开始安装"
pkg update -y
pkg install nodejs -y
pkg install yarn -y
pkg install build-essential -y
pkg install python -y
pkg install git -y
yarn global add code-server
echo "安装完成！有问题请截图，输入code-server启动vscode服务器"
sleep 2

