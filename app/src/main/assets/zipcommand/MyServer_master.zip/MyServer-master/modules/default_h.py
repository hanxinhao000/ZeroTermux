# Tool Name :- MyServer
# Author :- Rajkumar Dusad
# Date :- 22/July/2019
# Powered By :- Aex Software's

import sys
import os
from time import sleep
from core.system import *
from modules.open import *
from modules.local import *

def default_h():
  open()