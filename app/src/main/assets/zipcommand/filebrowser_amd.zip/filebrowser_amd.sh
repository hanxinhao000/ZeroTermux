#!/data/data/com.termux/files/usr/bin/sh
echo "欢迎安装filebrowser(amd)"
echo "作者地址:https://github.com/filebrowser/filebrowser"
echo "安装成功后开机自启"
echo "端口:19951"
echo "十秒钟后开始安装，请阅读"
sleep 10
echo "[*]开始安装"

cd ~

rm -rf .filebrowser

mkdir .filebrowser

cd .filebrowser

pkg update -y

pkg install wget proot git -y

wget http://od.ixcmstudio.cn/repository/main/filebrowser/linux-amd64.tar.gz

tar zxvf linux-amd64.tar.gz

rm linux-amd64.tar.gz

chmod 777 filebrowser



echo "安装完成！重启后运行"
sleep 2

